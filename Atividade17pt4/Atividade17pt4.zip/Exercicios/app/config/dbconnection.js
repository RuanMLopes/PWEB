var sql = require ('mssql');
 
var connSQLServer = function(){
   const sqlConfig = {
        user: 'BD2221029',
        password: 'P@ssw0rd!',
        database:'BD',
        server: 'APOLO',
        options:{
           encrypt: false,
           trustServerCertificate: true
       }
   }       
   return sql.connect(sqlConfig);
}
 
// exportando a função e quando chamar a página ele conecta
module.exports = function(){
  console.log('O autoload carregou o módulo de conexão com o bd');
  return connSQLServer;
}



// var sql = require('mssql');

// // module.exports = function()

// var connSQLServer = function(){
    
//     const config = {
//         user: 'BD2221029',
//         password: 'P@ssw0rd!',
//         database: 'BD', //Na FATEC, utilizar o database BD ou LP8
//         server: 'APOLO',
//         options: {
//             encrypt: false,
//             trustServerCertificate: true // se você não tiver um certificado de servidor configurado
//         }
//     }
//     return sql.connect(config);
// }

// module.exports = function(){
//     console.log('O autoload carregou o móudlo de conexão com o bd');
//     return connSQLServer;
// }