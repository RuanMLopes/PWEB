var sql = require('mssql');

module.exports = function(){
    
    const config = {
        user: 'BD2221029',
        password: 'P@ssw0rd!',
        database: 'BD', //Na FATEC, utilizar o database BD ou LP8
        server: 'APOLO',
        options: {
            encrypt: false,
            trustServerCertificate: true // se você não tiver um certificado de servidor configurado
        }
    }
    return sql.connect(config);
}