var texto = "Observer que essa mensagem vem do módulo";
module.exports = texto;